
-- 1. Create Database
create database geniusDb;
use geniusDb;

-- 2. Create Tables

-- Create the Department table
CREATE TABLE Department (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);

-- Create the Employee table
CREATE TABLE Employee (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(255) NOT NULL,
    last_name VARCHAR(255) NOT NULL,
    salary DECIMAL(10, 2) NOT NULL,
    joining_date DATE NOT NULL,
    departmentid INT,
    FOREIGN KEY (departmentid) REFERENCES Department(Id)
);
show databases;
show tables;

-- Insert  values into the Department table
INSERT INTO Department (Id, name) VALUES
    (1, 'HR'),
    (2, 'Finance'),
    (3, 'Engineering'),
    (4, 'Marketing'),
    (5, 'Biotechnology'),
    (6, 'Meturallgy');

-- Insert 10 values into the Employee table
INSERT INTO Employee (Id, first_name, last_name, salary, joining_date, departmentid) VALUES
    (1, 'Amit', 'Kumar', 25000, '2021-01-15', 1),
    (2, 'Priya', 'Sharma', 28000, '2021-02-20', 2),
    (3, 'Rahul', 'Gupta', 30000, '2021-03-10', 3),
    (4, 'Neha', 'Singh', 18000, '2021-04-05', 1),
    (5, 'Sandeep', 'Yadav', 27000, '2021-05-15', 2),
    (6, 'Pooja', 'Mishra', 32000, '2021-06-20', 3),
    (7, 'Ankit', 'Patel', 22000, '2021-07-10', 1),
    (8, 'Sneha', 'Verma', 26000, '2021-08-05', 2),
    (9, 'Rajesh', 'Shah', 29000, '2021-09-15', 3),
    (10, 'Kavita', 'Jain', 24000, '2021-10-20', 1),
    (11, 'Ankit', 'Patel', 62000, '2021-07-10', 4),
    (12, 'Sneha', 'Verma', 46000, '2021-08-05', 4);


select * from Employee;
select * from Department;

-- 3. Get nth salary salary

DELIMITER //
CREATE PROCEDURE NHighestSalary(IN value1 int,OUT value2 int) 
begin
set value2= (select salary from Employee ORDER BY `salary` ASC limit value1,1);
end;
//
delimiter ;
DELIMITER $$;

--Employee Operations
CREATE PROCEDURE EmployeeOperations()
BEGIN

    -- 4. Print all employees whose salary is in the range 15000 to 30000.
    SELECT * FROM Employee WHERE salary BETWEEN 15000 AND 30000;

    -- 5. Find all employee names whose second letter is 'a' and last second letter is 's'.
    SELECT * FROM Employee WHERE
        SUBSTRING(first_name, 2, 1) = 'a' AND
        SUBSTRING(last_name, -2, 1) = 's';

    -- 6. Print all employee names removing the last 3 letters.
    SELECT CONCAT(SUBSTRING(first_name, 1, LENGTH(first_name) - 3), ' ', SUBSTRING(last_name, 1, LENGTH(last_name) - 3)) AS ModifiedName FROM Employee;

    -- 7. Use all the aggregate functions on salary.
    SELECT
        AVG(salary) AS AverageSalary,
        MIN(salary) AS MinSalary,
        MAX(salary) AS MaxSalary,
        SUM(salary) AS TotalSalary
    FROM Employee;

    -- 8. Perform inner, full outer, left outer, and right outer join on the Employee and Department tables.
    
    -- Inner Join
   SELECT *
    FROM Employee
    INNER JOIN Department ON Employee.departmentid = Department.Id;


    SELECT *
    FROM Employee 
	 RIGHT JOIN Department  ON Employee.departmentid = Department.Id;
    
    SELECT *
    FROM Employee
	Left JOIN Department ON Employee.departmentid = Department.Id;

	SELECT *
    FROM Employee 
	 RIGHT JOIN Department  ON Employee.departmentid = Department.Id
     UNION
    SELECT *
    FROM Employee
	 Left JOIN Department ON Employee.departmentid = Department.Id;
     
END $$
DELIMITER ;

call NHighestSalary(11,@isPresent);
call EmployeeOperations();
select @isPresent;



