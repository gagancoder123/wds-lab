const mysql = require('mysql2');
const db = require('./db');
const bcrypt = require('bcrypt');
const connection = mysql.createConnection({
  host: '',
  user: '',
  password: '',
  database: '',
});

async function authenticateUser(username, password, callback) {
  try {
    const query = 'SELECT password FROM users WHERE username = ?';
    const [rows] = await db.promise().query(query, [username]);

    if (rows.length === 0) {
      callback(null, 'Username not found');
      return;
    }

    const hashedPasswordFromDB = rows[0].password;


    const passwordMatch = await bcrypt.compare(password, hashedPasswordFromDB);

    if (passwordMatch) {

      callback(null, 'Login successful', username);
    } else {

      callback(null, 'Wrong password');
    }
  } catch (error) {
    console.error('Error during authentication:', error);
    callback(error, null);
  } finally {
    db.end();
  }
}

module.exports = {
  authenticateUser,
};