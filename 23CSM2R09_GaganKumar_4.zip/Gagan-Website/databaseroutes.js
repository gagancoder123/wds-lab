const express = require('express');
const router = express.Router();
const db = require('./db');
router.get('/some-route', async (req, res, next) => {
  const connection = await db.promise().getConnection();

  try {
    const [rows] = await connection.query('SELECT * FROM use');
    res.json(rows);
  } catch (error) {
    next(error);
  } finally {
    connection.release();
  }
});

module.exports = router;