const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const path = require('path');
const mysql = require('mysql2');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const session = require('express-session');
const authentication = require('./authentication');

const app = express();
const port = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

const db = mysql.createConnection({
  host: '',
  user: '',
  password: '',
  database: ''
});

const databaseRoutes = require('./databaseroutes');

db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL database');
});

app.use(express.static(path.join(__dirname, 'public')));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const crypto = require('crypto');

function generateRandomString(length) {
  return crypto.randomBytes(length).toString('hex');
}

const secretKey = generateRandomString(32);


app.use(
  session({
    secret: secretKey,
    resave: true,
    saveUninitialized: true,
  })
);


app.use(passport.initialize());
app.use(passport.session());


app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


app.post('/register', async (req, res) => {
  const { name, username, password } = req.body;

  try {
    const hashedPassword = await bcrypt.hash(password, 10);

    const query = 'INSERT INTO use (id, name, username, password) VALUES (NULL, ?, ?, ?)';
    const values = [name, username, hashedPassword];

    db.query(query, values, (err, results) => {
      if (err) {
        console.error('Error registering user:', err);
        res.status(500).send('Registration failed');
        return;
      }

      console.log('User registered successfully');
      res.status(200).send('Registration successful');
    });
  } catch (error) {
    console.error('Error hashing password:', error);
    res.status(500).send('Registration failed');
  }
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

passport.use(
  new LocalStrategy((username, password, done) => {
    authentication.authenticateUser(username, password, async (error, authenticationResult) => {
      if (error) {
        return done(error);
      }

      if (authenticationResult === 'Login successful') {
        return done(null, { username });
      } else {
        return done(null, false, { message: 'Incorrect username or password' });
      }
    });
  })
);
passport.serializeUser((user, done) => {
  done(null, user);
});

passport.deserializeUser((user, done) => {
  done(null, user);
});

app.post(
  '/login',
  passport.authenticate('local', {
    failureRedirect: '/login', 
  }),
  (req, res) => {
    if (req.user.username === 'mainuser') {
      res.redirect('/mainuser-dashboard');
    } else {
      res.redirect('/home');
    }
  }
);

app.get('/home', async (req, res) => {
  try {
    const query = 'SELECT name, username FROM use WHERE username = ?';
    const [userRows] = await db.promise().query(query, [req.user.username]);

    if (userRows.length === 0) {
      res.status(404).send('User not found');
      return;
    }

    const user = userRows[0];

    res.render('home', { user });
  } catch (error) {
    console.error('Error fetching user data:', error);
    res.status(500).send('Something went wrong');
  }
});

function ismainuser(req, res, next) {
  if (req.isAuthenticated() && req.user.username === 'mainuser') {
    return next();
  }
  res.redirect('/login');
}


app.get('/mainuser-dashboard', ismainuser, async (req, res) => {
  try {
   
    const query = 'SELECT name, username FROM use';
    const [userRows] = await db.promise().query(query);

  
    res.render('mainuser-dashboard', { users: userRows });
  } catch (error) {
    console.error('Error fetching user data:', error);
    res.status(500).send('Something went wrong');
  }
});

app.use('/api', databaseRoutes);
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).send('Something went wrong');
});

app.listen(port, '',() => {
  console.log(`Server is running on ${port}`);
});
