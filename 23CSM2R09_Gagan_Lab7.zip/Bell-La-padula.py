# Classification levels
secClassificationLvls = {
    "unclassified": 1,
    "confidential": 2,
    "secret": 3,
    "top secret": 4
}

# Categories
categories = {'c1', 'c2', 'c3'}

# Class to create subject with max security level (clearance)
class createSub:
    def __init__(self, name, cls, category):
        self.name = name
        self.cls = cls
        self.category = category
        self.currCls = cls  # Initialize current security level with max clearance
        self.currCategory = category  # Initialize current category with max category
        self.active = True  # Subjects are initially active
        print(f"Successfully created subject {name} with security clearance {cls, category}")

    # Function to change the current security level of subject
    def changeSubCurrentSecLevel(self, curr, category):
        # Check if the new security level is lower or equal and the category is a subset of the subject's category
        if (secClassificationLvls[curr] <= secClassificationLvls[self.cls] and category.issubset(self.category)):
            self.currCls = curr
            self.currCategory = category
            print(f"Successfully changed subject {self.name} current security level to {curr, category}")
        else:
            print(f"Change of subject {self.name} current security level is unsuccessful")

    # Function to deactivate a subject
    def deactivate(self):
        self.active = False
        print(f"Deactivated subject {self.name}")

    # Function to print the clearance level, current security level, and activity status
    def printSecurityLevel(self):
        print(f"Max security classification of {self.name} is {self.cls}")
        print(f"Max security category of {self.name} is {self.category}")
        print(f"Current security classification of {self.name} is {self.currCls}")
        print(f"Current security category of {self.name} is {self.currCategory}")
        print(f"Subject {self.name} is {'active' if self.active else 'inactive'}")

# Class to change the security level of object
class changeObjSecLevel:
    def __init__(self, name, classification, category):
        self.name = name
        self.classification = classification
        self.category = category
        self.active = True  # Objects are initially active
        print(f"Successfully changed object {name} current security level {classification, category}")

    # Function to deactivate an object
    def deactivate(self):
        self.active = False
        print(f"Deactivated object {self.name}")

    # Function to print the security level and activity status
    def printSecurityLevel(self):
        print(f"Security classification of {self.name} is {self.classification}")
        print(f"Security category of {self.name} is {self.category}")
        print(f"Object {self.name} is {'active' if self.active else 'inactive'}")

# No read-up condition for confidentiality
def readObj(subject, obj):
    if subject.active and obj.active and secClassificationLvls[subject.currCls] >= secClassificationLvls[obj.classification] and subject.currCategory.issuperset(obj.category):
        print(f"Subject {subject.name} has read access on object {obj.name}")
    else:
        print(f"Subject {subject.name} doesn't have read access on object {obj.name}")

# No write-down condition for confidentiality
def writeToObj(subject, obj):
    if subject.active and obj.active and secClassificationLvls[subject.currCls] <= secClassificationLvls[obj.classification] and subject.currCategory.issubset(obj.category):
        print(f"Subject {subject.name} has write access on object {obj.name}")
    else:
        print(f"Subject {subject.name} doesn't have write access on object {obj.name}")

# Creating subjects and objects
s1 = createSub('s1', "unclassified", {'c1', 'c2'})
s2 = createSub('s2', "secret", {'c2', 'c3', 'c1'})
o1 = changeObjSecLevel('o1', "unclassified", {'c2'})
o2 = changeObjSecLevel('o2', 'top secret', {'c2', 'c3', 'c1'})

# Changing subject and object security levels
s1.changeSubCurrentSecLevel('secret', {'c1'})
s2.changeSubCurrentSecLevel('unclassified', {'c1'})
s2.changeSubCurrentSecLevel('top secret', {'c3'})

# Deactivating subject and object
s2.deactivate()
o1.deactivate()

# Checking access to objects
readObj(s1, o1)  # Should have read access
readObj(s1, o2)  # Should not have read
