#include <bits/stdc++.h>
using namespace std;

int main() {
    // Initialize a 2x4 vector of strings
    vector<vector<string>> v(2, vector<string>(4));

    // Display the initial graph
    cout << "        ->->-> ->->-> ->->-> ->->-> ->->->   Initial Graph   <-<-<- <-<-<- <-<-<- <-<-<- <-<-<- <-<-<-" << endl;
    cout << endl;
    cout<<endl;
    // Initialize the vector elements
    v[0][0] = "0";
    v[0][1] = "rw";
    v[0][2] = "r";
    v[0][3] = "0";
    v[1][0] = "0";
    v[1][1] = "0";
    v[1][2] = "0";
    v[1][3] = "r";

    // Display the initial graph in a nicely formatted table
    cout << "       sub1 sub2 obj1 obj2";
    cout<<endl;
    for (int i = 0; i < 2; i++) {
        cout << "Sub" << i + 1 << "-->  ";
        for (int j = 0; j < 4; j++) {
            cout << v[i][j] << "   ";
        }
        cout << endl;
    }

    // Prompt the user for an option
    cout << "Option 1: Grant" << endl;
    cout<<endl;
    cout << "Option 2: Take" << endl;
    cout<<endl;
    cout<<  "Option 3: Remove"<<endl;
    cout<<endl;
    cout << "Enter the option: ";
    cout<<endl;
    int n;
    cin >> n;
    cout<<endl;


    // Process the chosen option
    if (n == 1) {
        cout<<"  ->->->   ->->->   ->->->    Sub1 Have Granted Their Rights to Sub2  <-<-<-  <-<-<-  <-<-<- "<<endl;
        cout<<"  ->->->   ->->->   ->->->         Grant Successfully Completed  <-<-<-   <-<-<-  <-<-<-  <-<-<- "<<endl;
        for (int i = 0; i < 4; i++) {
            // Combine and remove duplicates from the strings
            v[1][i] = v[1][i] + v[0][i];
            string input = v[1][i];
            auto last = unique(input.begin(), input.end());
            input.erase(last, input.end());
            
            // Remove '0' and any other duplicates
            string t;
            if(input.length()>1)
            {
            for (int i = 0; i < input.length(); i++) 
            {
                if (input[i] != '0')
                {
                    t += input[i];
                }
            }
            input=t;
            }
            v[1][i] = input;
        }
    } 
    else if (n == 2)
    {
        cout<<"   ->->->    ->->->   ->->-> Sub 1 Have Taken the Righs of Sub 2  <-<-<-   <-<-<-   <-<-<-"<<endl;
        cout<<"   ->->->    ->->->   ->->->    Take Successfully Completed  <-<-<-   <-<-<-   <-<-<-"<<endl;
        cout<<endl;
        for (int i = 0; i < 4; i++) 
        {
            // Combine and remove duplicates from the strings
            v[0][i] = v[1][i] + v[0][i];
            string input = v[0][i];
            auto last = unique(input.begin(), input.end());
            input.erase(last, input.end());

            // Remove '0' and any other duplicates
            string t;
            if(input.length()>1)
            {
            for (int i = 0; i < input.length(); i++)
            {
                if (input[i] != '0') {
                    t += input[i];
                }
            }
            input=t;
            }
            v[0][i] = input;
        }
    } 
    else if(n==3)
    {
    	cout<<endl;
		cout<<"Enter Subject Number and Object Number And Right to remove"<<endl;
		cout<<endl;
		cout<<"Enter Subject Number"<<endl;
		int a;
		cin>>a;
		cout<<"Enter Object Number"<<endl;
		int b;
		cin>>b;
		cout<<"Enter Rights"<<endl;
		char q;
		cin>>q;
		string aa=v[a-1][b-1];
		string w;
		for(int k=0;k<aa.length();k++)
		{
			if(aa[k]!=q)
			{
				w=w+aa[k];
			}
		}
		if((w.length())==0)
		v[a-1][b-1]="0";
		else
		v[a-1][b-1]=w;
	cout << "  ->->->  ->->->  ->->->  ->->->  Updated Graph  <-<-<-  <-<-<-  <-<-<-  <-<-<-" << endl;
    cout << "        sub1  sub2  obj1  obj2"<<endl;
    for (int i = 0; i < 2; i++) 
    {
        cout << "Sub" << i + 1 << "-->  ";
        for (int j = 0; j < 4; j++)
        {
            
            cout << v[i][j] << "   ";
        }
        cout << endl;
    }
	return 0;	
	}
    else
    {
        cout << "Enter only available rights (1 or 2)." << endl;
    }

    // Display the updated graph in a nicely formatted table
    cout<<endl;
    cout<<endl;
    cout << "  ->->->  ->->->  ->->->  ->->->  Updated Graph  <-<-<-  <-<-<-  <-<-<-  <-<-<-" << endl;
    cout << "        sub1  sub2  obj1  obj2"<<endl;
    for (int i = 0; i < 2; i++) 
    {
        cout << "Sub" << i + 1 << "-->  ";
        for (int j = 0; j < 4; j++)
        {
            cout << v[i][j] << "     ";
        }
        cout << endl;
    }

    return 0;
}